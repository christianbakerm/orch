﻿README

Ansible – Oracle 12c RDBMS Software-Only Install

Purpose:

This zip file comprises a complete Ansible Playbook that when executed will complete the following steps:

- Create the oracle OS user
- Grant membership in various OS groups to oracle
- Create devices and mount points for devices sdb thru sde
- Create the /u01/app/oracle and /u01/app/oraInventory folders as the target for software installs
- Establish symbolic links to the devices for the orabin, oradata1, oradata2 and oraarchive  folders
- Transfer and decompress a ZIP file containing the Oracle 12c RDBMS software (linux_12*.zip)
- Transfer a standard response file to be used by the Oracle installer for installing the software/binaries
- Execute the Oracle Universal Installer to confirm all necessary installation pre-requisites
- Silently run the Oracle Universal Installer to place the software as designed
- Execute the necessary scripts (using root user) as required by the Oracle installation

Pre-execution Pre-requisites:

All the following items MUST be functional when Ansible interacts with the target server(s) prior to executing Ansible.

- RHEL 7.7 installed and running
- Passwordless SSH access established for the user used to connect to the target environment (username and path to SSH keys can be revised in the “all” file located within the ./inventories/group_vars folder).  In the current configuration, the configuration utilizes an ‘ec2-user’ (for accessing AWS) but the key file has been removed from the folders.
- sudo access (wheel group membership) for the user connecting (via passwordless ssh) to each target server.
- Functional Ansible ‘master’ with connectivity to all the target servers.
- List of target servers can be revised by editing the ‘hosts’ file located at the Ansible root.
- The target server adheres to the standards documented within the text document produced by the TIOCA CLASS development team – including but not limited to the use of an ‘oracle’ OS user, various OS groups, and permissions on the various devices.
