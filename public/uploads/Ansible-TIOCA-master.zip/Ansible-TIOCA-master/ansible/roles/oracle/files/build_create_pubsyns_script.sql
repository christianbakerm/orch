set serveroutput on size 1000000
set linesize 100
spool create_pubsyns.sql

declare
    v_synonym        varchar2(128);
    v_owner          varchar2(128);
    v_object         varchar2(128);

    cursor c1 is
     select trim(synonym_name), trim(table_owner), trim(table_name)
       from dba_synonyms
      where table_owner in ('BNS','CXI','CLASS_AQ')
      order by 2,1;

begin
    open c1;
    fetch c1 into v_synonym, v_owner, v_object;

    loop
        exit when c1%NOTFOUND;

        dbms_output.put_line('create public synonym ' || v_synonym || ' for ' || v_owner || '.' || v_object || ';');

        fetch c1 into v_synonym, v_owner, v_object;
    end loop;

    close c1;

end;
/

spool off
set linesize 80
