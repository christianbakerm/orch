set serveroutput on size 1000000
set linesize 1024
spool create_tablespaces.sql

declare
    v_ts           varchar2(30);
    v_prev_ts      varchar2(30) := '...';
    v_file_name    varchar2(513);
    v_bytes        number;

    cursor c1 is
     select tablespace_name, trim(file_name), bytes 
       from dba_data_files
      where tablespace_name not in ('SYSTEM','SYSAUX')
        and tablespace_name not like 'UNDO%'
        and tablespace_name not like 'TEMP%'
      order by tablespace_name, file_id;

begin
    open c1;
    fetch c1 into v_ts, v_file_name, v_bytes;

    loop
        exit when c1%NOTFOUND;

        if v_ts != v_prev_ts then
            dbms_output.put_line('create tablespace ' || v_ts || ' datafile ' || chr(39) || v_file_name || chr(39) || ' size ' || v_bytes || ' autoextend on next 10m maxsize 30000m;');
        else
            dbms_output.put_line('alter tablespace ' || v_ts || ' add datafile ' || chr(39) || v_file_name || chr(39) || ' size ' || v_bytes || ' autoextend on next 10m maxsize 30000m;');
        end if;

        v_prev_ts := v_ts;

        fetch c1 into v_ts, v_file_name, v_bytes;
    end loop;

    close c1;

end;
/

spool off
set linesize 80
