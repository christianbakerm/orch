-- Edit as necessary.

create user bns identified by {{ bns }}
   default tablespace data
   temporary tablespace temp;

create user bns_app identified by {{ bns_app }}
   default tablespace data
   temporary tablespace temp;

create user cxi identified by {{ cxi }}
   default tablespace data
   temporary tablespace temp;

create user cxi_app identified by {{ cxi_app }}
   default tablespace data
   temporary tablespace temp;

create user rch identified by {{ rch }}
   default tablespace rch
   temporary tablespace temp;


grant bns_query, bns_update                        to bns;
grant bns_query, bns_update                        to bns_app;
grant bns_query, bns_update, cxi_query, cxi_update to cxi;
grant bns_query, bns_update, cxi_query, cxi_update to cxi_app;
grant rch_role, bns_query, cxi_query               to rch;
