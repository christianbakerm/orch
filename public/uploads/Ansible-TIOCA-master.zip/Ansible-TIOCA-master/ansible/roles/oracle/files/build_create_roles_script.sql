set serveroutput on size 1000000
set linesize 1024
spool create_roles.sql

declare
    v_role        varchar2(30);

    cursor c1 is
     select role
       from dba_roles
      where role like 'BNS%'
         or role like 'CLASS_AQ%'
         or role like 'CCDI%'
         or role like 'CLASS%'
         or role like 'CXI%'
         or role like 'DB_MON%'
         or role like 'ECLASS%'
         or role like 'RCH%'
      order by role;

begin
    open c1;
    fetch c1 into v_role;

    loop
        exit when c1%NOTFOUND;

        dbms_output.put_line('create role ' || v_role || ' not identified;');

        fetch c1 into v_role;
    end loop;

    close c1;

end;
/

spool off
set linesize 80
